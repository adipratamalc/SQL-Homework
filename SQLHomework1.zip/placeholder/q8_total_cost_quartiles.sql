WITH result AS(
    SELECT IFNULL(CompanyName, 'MISSING_NAME') AS CompanyNames, CustomerId, NTILE(4) OVER (ORDER BY ROUND(SUM(UnitPrice *Quantity),2)) AS q, 
    ROUND(SUM(UnitPrice *Quantity),2) as TCost
    FROM  'Order'
    LEFT JOIN OrderDetail 
    ON OrderDetail.OrderId ='Order'.Id  
    LEFT JOIN Customer
    ON Customer.Id ='Order'.CustomerId
    GROUP BY CustomerId
    )
SELECT CompanyNames, CustomerId, TCost
FROM result
WHERE q = 1
ORDER BY TCost ASC
;