SELECT DISTINCT ShipName, SUBSTRING(Shipname, 1, INSTR(ShipName,'-')-1) 
FROM 'Order' 
WHERE ShipName 
LIKE '%-%' 
ORDER by ShipName ASC;