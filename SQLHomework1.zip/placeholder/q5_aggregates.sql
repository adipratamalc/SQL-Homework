SELECT CategoryName,
COUNT(Product.Id), 
ROUND(AVG(UnitPrice),2),
MIN(UnitPrice), MAX(UnitPrice), SUM(UnitsOnOrder)
from Category
LEFT JOIN  Product
ON Category.Id = Product.CategoryId
GROUP BY CategoryName;