SELECT  'Order'.Id, OrderDate,
Lag(OrderDate, 1, 0) OVER(ORDER BY OrderDate) AS PreviousDate,
ROUND(julianday(OrderDate) - julianday(Lag(OrderDate, 1, 0) OVER(ORDER BY OrderDate)),2)
FROM 'Order' 
LEFT JOIN Customer
ON 'Order'.CustomerId = Customer.Id
WHERE CustomerId='BLONP' 
ORDER BY OrderDate
LIMIT 10;