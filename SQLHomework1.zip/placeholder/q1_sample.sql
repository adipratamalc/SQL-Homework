SELECT CategoryName 
FROM Category 
ORDER BY CategoryName;
