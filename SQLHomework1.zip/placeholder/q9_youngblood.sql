SELECT RegionDescription, FirstName, LastName, BirthDate
FROM Region
LEFT JOIN Territory
ON Region.Id = RegionId
LEFT JOIN EmployeeTerritory
ON Territory.Id = TerritoryId
LEFT JOIN Employee
ON EmployeeId = Employee.id
WHERE BirthDate
GROUP BY RegionDescription
HAVING MIN(BirthDate)
ORDER BY RegionId
;