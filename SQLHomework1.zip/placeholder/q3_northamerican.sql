SELECT id, ShipCountry, 
CASE WHEN ShipCountry = 'USA' OR ShipCountry = 'Mexico' OR ShipCountry = 'Canada' 
    THEN 'NorthAmerica'
    ELSE 'OtherPlace'
END Place
FROM 'Order' 
WHERE Id >= 15445
ORDER by Id ASC 
LIMIT 20;