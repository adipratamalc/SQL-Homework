SELECT CompanyName, 
ROUND(ROUND(COUNT(CASE WHEN julianday(ShippedDate) > julianday(RequiredDate) THEN 'late' END)) / ROUND(COUNT('Order'.Id)) * 100,2)
FROM Shipper
LEFT JOIN  'Order'
ON Shipper.Id = 'Order'.ShipVia 
GROUP BY Shipper.id;

