WITH Products  AS(SELECT ProductName, CompanyName,ContactName,
    ROW_NUMBER() OVER(PARTITION BY ProductName ORDER BY OrderDate ) AS rank
    FROM OrderDetail
    LEFT JOIN Product 
    ON OrderDetail.ProductId = Product.Id
    LEFT JOIN 'Order'
    ON OrderDetail.OrderId = 'Order'.Id
    LEFT JOIN  Customer
    ON 'Order'.CustomerId = Customer.Id
    WHERE Discontinued = 1 )
SELECT ProductName, CompanyName, ContactName
FROM Products
WHERE rank = 1;