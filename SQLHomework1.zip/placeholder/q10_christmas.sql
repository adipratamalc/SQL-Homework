SELECT DISTINCT GROUP_CONCAT(Product.ProductName, ', ') OVER (ORDER BY Product.Id ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING)
FROM Product
LEFT JOIN OrderDetail 
ON OrderDetail.ProductId = Product.Id
LEFT JOIN 'Order' 
ON OrderDetail.OrderId = 'Order'.Id
LEFT JOIN Customer 
ON 'Order'.CustomerId = Customer.Id
WHERE DATE('Order'.OrderDate) = '2014-12-25' AND Customer.CompanyName = 'Queen Cozinha'
ORDER BY OrderDetail.ProductId;
